import streamlit as st
import pandas as pd
import numpy as np
from pathlib import Path

st.set_page_config(page_title="Smart Finds Telugu | Affiliate Analytics", page_icon="📊", layout="wide")

st.markdown("""
<style>
.block-container {padding-top: 1.4rem; padding-bottom: 2rem;}
[data-testid="stMetric"] {background: #f4f6fa; border: 1px solid #e7eaf0; padding: 14px 16px; border-radius: 12px;}
.small-note {color: #687386; font-size: 0.88rem;}
</style>
""", unsafe_allow_html=True)

ROOT = Path(__file__).parent
DEFAULT_DATA = ROOT / "data" / "sample_affiliate_data.csv"

@st.cache_data
def load_csv(file_or_path):
    return pd.read_csv(file_or_path)

def prepare_data(df):
    required = ["Date","Platform","Product","Category","Campaign","Clicks","Orders",
                "Sales_INR","Commission_Earned_INR","Reversals_INR","Marketing_Expenses_INR"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError("Missing required columns: " + ", ".join(missing))
    df = df.copy()
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    numeric = required[5:]
    for c in numeric:
        df[c] = pd.to_numeric(df[c], errors="coerce").fillna(0)
    df = df.dropna(subset=["Date"])
    for c in ["Clicks","Orders"]:
        df[c] = df[c].clip(lower=0)
    for c in ["Sales_INR","Commission_Earned_INR","Reversals_INR","Marketing_Expenses_INR"]:
        df[c] = df[c].clip(lower=0)
    df["Net_Commission_INR"] = df["Commission_Earned_INR"] - df["Reversals_INR"]
    df["Net_Profit_INR"] = df["Net_Commission_INR"] - df["Marketing_Expenses_INR"]
    df["Conversion_Rate"] = np.where(df["Clicks"] > 0, df["Orders"] / df["Clicks"] * 100, 0)
    return df

st.title("📊 Smart Finds Telugu")
st.subheader("Affiliate Marketing Analytics Dashboard")
st.caption("Amazon · Flipkart · Meesho | Sales, traffic, commission and profitability")

with st.sidebar:
    st.header("Data source")
    uploaded = st.file_uploader("Upload your affiliate CSV", type=["csv"])
    st.caption("No actual affiliate accounts are connected. Start with the included synthetic sample data.")
    st.divider()
    st.header("Filters")

try:
    raw = load_csv(uploaded) if uploaded is not None else load_csv(DEFAULT_DATA)
    data = prepare_data(raw)
except Exception as e:
    st.error(f"Could not load the data: {e}")
    st.stop()

if data.empty:
    st.warning("No valid rows found in the selected data.")
    st.stop()

min_date, max_date = data["Date"].min().date(), data["Date"].max().date()
with st.sidebar:
    date_range = st.date_input("Date range", value=(min_date, max_date), min_value=min_date, max_value=max_date)
    platform_options = sorted(data["Platform"].dropna().unique().tolist())
    selected_platforms = st.multiselect("Platform", platform_options, default=platform_options)
    product_options = sorted(data["Product"].dropna().unique().tolist())
    selected_products = st.multiselect("Product", product_options, default=product_options)
    campaign_options = sorted(data["Campaign"].dropna().unique().tolist())
    selected_campaigns = st.multiselect("Campaign", campaign_options, default=campaign_options)

filtered = data.copy()
if isinstance(date_range, (tuple, list)) and len(date_range) == 2:
    start, end = pd.Timestamp(date_range[0]), pd.Timestamp(date_range[1]) + pd.Timedelta(days=1) - pd.Timedelta(seconds=1)
    filtered = filtered[(filtered["Date"] >= start) & (filtered["Date"] <= end)]
filtered = filtered[
    filtered["Platform"].isin(selected_platforms) &
    filtered["Product"].isin(selected_products) &
    filtered["Campaign"].isin(selected_campaigns)
]

if filtered.empty:
    st.info("No records match the selected filters. Change the filters in the sidebar.")
    st.stop()

sales = filtered["Sales_INR"].sum()
clicks = int(filtered["Clicks"].sum())
orders = int(filtered["Orders"].sum())
commission = filtered["Commission_Earned_INR"].sum()
reversals = filtered["Reversals_INR"].sum()
expenses = filtered["Marketing_Expenses_INR"].sum()
net_commission = commission - reversals
profit = net_commission - expenses
conversion = orders / clicks * 100 if clicks else 0
currency = lambda x: f"₹{x:,.0f}"

st.info("DEMO DATA: All figures are synthetic examples for dashboard development. They are not actual Smart Finds Telugu earnings or platform-reported results.")

k1,k2,k3,k4 = st.columns(4)
k1.metric("Total product sales", currency(sales))
k2.metric("Affiliate clicks", f"{clicks:,}")
k3.metric("Orders", f"{orders:,}")
k4.metric("Conversion rate", f"{conversion:.2f}%")
k5,k6,k7,k8 = st.columns(4)
k5.metric("Commission earned", currency(commission))
k6.metric("Commission reversals", currency(reversals))
k7.metric("Marketing expenses", currency(expenses))
k8.metric("Net profit", currency(profit), help="Commission earned − reversals − marketing expenses")

st.divider()
left,right = st.columns(2)
with left:
    st.subheader("Monthly performance")
    monthly = filtered.set_index("Date").resample("MS")[["Sales_INR","Commission_Earned_INR","Reversals_INR","Marketing_Expenses_INR"]].sum()
    monthly.index = monthly.index.strftime("%b %Y")
    monthly = monthly.rename(columns={"Sales_INR":"Product sales","Commission_Earned_INR":"Commission","Reversals_INR":"Reversals","Marketing_Expenses_INR":"Expenses"})
    st.line_chart(monthly)
with right:
    st.subheader("Performance by platform")
    by_platform = filtered.groupby("Platform")[["Sales_INR","Commission_Earned_INR","Reversals_INR","Marketing_Expenses_INR"]].sum()
    by_platform = by_platform.rename(columns={"Sales_INR":"Product sales","Commission_Earned_INR":"Commission earned","Reversals_INR":"Reversals","Marketing_Expenses_INR":"Expenses"})
    st.bar_chart(by_platform[["Commission earned","Reversals","Expenses"]])

left,right = st.columns(2)
with left:
    st.subheader("Top products by sales")
    top_products = filtered.groupby("Product")["Sales_INR"].sum().sort_values(ascending=False).head(10)
    st.bar_chart(top_products)
with right:
    st.subheader("Clicks and orders by campaign")
    campaign = filtered.groupby("Campaign")[["Clicks","Orders"]].sum().sort_values("Clicks",ascending=False)
    st.bar_chart(campaign)

st.subheader("Product-level performance")
product_table = filtered.groupby(["Product","Platform"], as_index=False).agg(
    Clicks=("Clicks","sum"), Orders=("Orders","sum"), Product_Sales_INR=("Sales_INR","sum"),
    Commission_INR=("Commission_Earned_INR","sum"), Reversals_INR=("Reversals_INR","sum"),
    Marketing_Expenses_INR=("Marketing_Expenses_INR","sum"))
product_table["Net_Profit_INR"] = product_table["Commission_INR"] - product_table["Reversals_INR"] - product_table["Marketing_Expenses_INR"]
product_table["Conversion_Rate_%"] = np.where(product_table["Clicks"]>0, product_table["Orders"]/product_table["Clicks"]*100,0)
st.dataframe(product_table.sort_values("Product_Sales_INR",ascending=False), use_container_width=True, hide_index=True)

st.subheader("Filtered data")
st.dataframe(filtered.sort_values("Date",ascending=False), use_container_width=True, hide_index=True)
st.download_button("⬇️ Download filtered data as CSV", filtered.to_csv(index=False).encode("utf-8"), "smart_finds_filtered_data.csv", "text/csv")

with st.expander("Metric definitions and assumptions"):
    st.markdown("""
    - **Product sales:** order value attributed to affiliate links; this is not your income.
    - **Commission earned:** estimated affiliate commission in the sample or entered in your uploaded report.
    - **Reversals:** commission removed for cancellations, returns or rejected orders.
    - **Net commission:** commission earned minus reversals.
    - **Marketing expenses:** manually tracked promotional/ad/content costs.
    - **Net profit:** net commission minus marketing expenses. It is a simplified contribution measure before tax and any unrecorded costs.
    - **Conversion rate:** orders divided by clicks. For aggregated rows, this is recalculated from total clicks and orders.

    Sample commission rates and sample transactions are illustrative only. Actual platform rates, attribution rules, reporting fields and payment status vary.
    """)

st.caption("Smart Finds Telugu · Built with Python, Pandas, NumPy and Streamlit")
