# Smart Finds Telugu — Affiliate Marketing Analytics Dashboard

An interactive portfolio dashboard built with **Python, Streamlit, Pandas and NumPy** for tracking affiliate marketing performance across Amazon, Flipkart and Meesho.

## Features
- KPI summary: product sales, clicks, orders, conversion rate, commission, reversals, expenses and net profit.
- Filters for date range, platform, product and campaign.
- Monthly performance charts.
- Platform and product comparisons.
- Campaign click/order analysis.
- Product-level performance table and filtered CSV download.
- Upload your own CSV using the sidebar.

## Run locally
1. Install Python 3.10 or later.
2. Extract this project ZIP and open a terminal in the project folder.
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Start the dashboard:
   ```bash
   streamlit run app.py
   ```
5. Streamlit opens the dashboard in your browser.

## Data source and important note
The included `data/sample_affiliate_data.csv` is **synthetic demo data** created for portfolio and testing purposes. It is not actual Smart Finds Telugu sales, commissions, orders, clicks, or earnings. Sample commission assumptions are illustrative, not official affiliate rates. Replace it with your actual exported affiliate reports when available.

## CSV upload format
Your CSV must contain these columns:
`Date, Platform, Product, Category, Campaign, Clicks, Orders, Sales_INR, Commission_Earned_INR, Reversals_INR, Marketing_Expenses_INR`

- `Date`: YYYY-MM-DD recommended.
- `Platform`: Amazon, Flipkart or Meesho.
- `Clicks`, `Orders`: non-negative counts.
- Monetary fields: numeric INR values.
- Marketing expenses can be entered by campaign/day or set to 0 when not applicable.

## Metric definitions
- Product sales = sum of attributed order value.
- Net commission = commission earned − reversals.
- Net profit = net commission − marketing expenses.
- Conversion rate = orders ÷ clicks × 100.

## Suggested GitHub repository description
`Interactive affiliate marketing analytics dashboard built with Python and Streamlit to track clicks, orders, product sales, commissions, reversals, expenses and net profit across Amazon, Flipkart and Meesho.`
